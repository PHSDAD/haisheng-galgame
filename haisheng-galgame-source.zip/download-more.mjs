import fs from 'node:fs/promises';
const sources={
 'dist/assets/judy-neutral.png':'https://toppng.com/uploads/preview/share-this-image-diy-judy-hopps-costume-11563500903ycgxn9sju9.png',
 'dist/assets/judy-wave.png':'https://www.pngfind.com/pngs/b/207-2079225_judy-hopps-hd-png-download.png',
 'dist/assets/judy-badge.png':'https://w7.pngwing.com/pngs/504/822/png-transparent-lt-judy-hopps-nick-wilde-costume-police-officer-clothing-theather-halloween-costume-rabbit-rabits-and-hares.png',
 'dist/assets/judy-crossed.png':'https://toppng.com/uploads/preview/imagenes-de-zootopia-con-fondo-transparente-descarga-personajes-de-zootopia-conejo-115630353071jf0b0gtdm.png',
 'bg-preview-1.jpg':'https://img.itch.zone/aW1hZ2UvMjM2MDY3NC8xMzk4MjI5Ni5qcGc=/original/lH8zgD.jpg',
 'bg-preview-2.jpg':'https://img.itch.zone/aW1hZ2UvMjM2MDY3NC8xMzk4MjI2MS5qcGc=/original/gmz4d0.jpg',
 'bg-preview-3.jpg':'https://img.itch.zone/aW1hZ2UvMjM2MDY3NC8xMzk4MjI2Mi5qcGc=/original/TXNdhz.jpg',
 'bg-preview-4.jpg':'https://img.itch.zone/aW1hZ2UvMjM2MDY3NC8xMzk4MjI2Ni5qcGc=/original/dBNSzy.jpg'
};
await Promise.all(Object.entries(sources).map(async([name,url])=>{for(let attempt=0;attempt<3;attempt++){try{const r=await fetch(url,{signal:AbortSignal.timeout(20000)});if(!r.ok)throw Error('HTTP '+r.status);const data=Buffer.from(await r.arrayBuffer());await fs.writeFile(name,data);console.log(name+': '+data.length);return;}catch(e){if(attempt===2)console.log(name+': FAILED '+e.message);}}}));
