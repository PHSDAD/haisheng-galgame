# 拥抱 CG 生成记录

使用内置 image_gen；最终图已保存进游戏目录，没有使用 CLI 或 API 密钥。

- 雨姐：`dist/assets/cg-rain.png`
- 噶辉：`dist/assets/cg-gah.png`
- Judy：拥抱图未通过生成服务。用户已选择先采用潘海生与原作 Judy 立绘同框、动态爱心的过渡方案。后续可在 game.js 的 cgFiles.judy 填入新图片文件名替换，当前不将该过渡画面标注为拥抱图。

## 雨姐最终提示词

The two adult people from Image 1 and Image 2 share a warm joyful mutual hug after confessing affection, shown waist-up, bodies naturally angled toward one another, their recognizable faces both clearly visible. Preserve the exact adult faces, apparent ages and realistic photographic likenesses. Image 1 adult wears rectangular black glasses, natural short black hair, charcoal black polo shirt, no cap/backpack. Image 2 adult wears her recognizable floral vest over white sleeves with pulled-back hair. Warm smiling expressions. A hand-painted Japanese-anime style university courtyard at pink sunset behind them, deliberately mixed photorealistic subjects and anime background. Small cute floating pink hearts around the hug, soft golden rim light, blush pink romantic atmosphere. Wide 16:9 visual novel ending CG, characters in center with room above/beside for hearts, beautifully composed. Fully clothed, wholesome affectionate embrace, no kissing, no text, no watermark.

## 噶辉最终提示词

The two adult people from Image 1 and Image 2 share a shy tender mutual hug after a campus confession, waist-up, both recognizable faces clearly visible, adult proportions and natural arms/hands. Preserve the exact faces, black glasses and realistic photographic likenesses from both references, no beautification or de-aging. First adult wears a charcoal black polo, natural short black hair, no cap or backpack. Second adult retains the medium layered black hair and loose white long sleeve shirt and glasses of Image 2. Both smile softly, a little flustered. Empty hand-painted Japanese-anime style university classroom at pink sunset behind them, intentionally photographic people in anime scenery. Small floating pink hearts around them, soft peach light, cute romance-visual-novel ending illustration. Wide 16:9 composition, two people centered, no other people, fully clothed wholesome hug, no kissing, no text or watermark.

