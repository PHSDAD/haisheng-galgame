import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const context={window:{}};vm.runInNewContext(fs.readFileSync('dist/story.js','utf8'),context);const s=context.window.VN_STORY;
assert.equal(Object.keys(s.endings).length,3);
assert.equal(s.chars.rain.single,true,'rain must use isolated portraits, not atlas crops');
assert.equal(new Set(s.chars.rain.variants).size,4,'rain needs four independent expressions');
for(const name of ['pink.css','bow.svg','rally.js','assets/cg-rain.png','assets/cg-gah.png'])assert.ok(fs.existsSync('dist/'+name),`missing ${name}`);
const engine=fs.readFileSync('dist/game.js','utf8'),html=fs.readFileSync('dist/index.html','utf8');
assert.ok(engine.includes("e.chapter===5")&&engine.includes('launchRally(true)'),'missing chapter 5 warmup');
assert.ok(engine.includes('showEndingCG(e.ending)'),'ending must lead to CG');
assert.ok(html.includes('data-action="practice"')&&html.includes('id="cg-screen"'),'missing visible entries');
const choices=new Map(s.common.filter(e=>e.type==='choice').map(e=>[e.key,e]));
assert.equal(choices.size,7);assert.equal(s.common.at(-1).type,'final');
for(const [route,entries]of [['common',s.common],...Object.entries(s.endings).map(([id,v])=>[id,v.entries])]){
 for(const e of entries){
  if(e.type==='line'||e.type==='conditional'){assert.ok(s.chars[e.speaker],`missing speaker ${e.speaker}`);assert.ok(e.text.length>0);assert.ok(e.mood>=0&&e.mood<=3);}
  if(e.type==='conditional'){assert.ok(choices.has(e.key));assert.ok(e.value<choices.get(e.key).options.length);}
  if(e.type==='cast')for(const id of e.ids)assert.ok(s.chars[id],`missing cast ${id}`);
  if(e.type==='scene')assert.ok(fs.existsSync('dist/assets/'+({gym:'gym.png'}[e.bg]||e.bg+'.jpg')),`missing ${e.bg}`);
  if(e.type==='choice'){assert.equal(e.options.length,3);for(const o of e.options)assert.ok(s.chars[o.speaker]);}
 }
 if(route!=='common'){assert.equal(entries.at(-1).type,'end');assert.equal(entries.at(-1).ending,route);}
}
for(const c of Object.values(s.chars))for(const image of [c.sheet,...(c.variants||[])].filter(Boolean))assert.ok(fs.existsSync('dist/assets/'+image),`missing ${image}`);
for(const index of [0,1,2])for(const ending of Object.keys(s.endings)){
 const selected=Object.fromEntries([...choices].map(([k])=>[k,index]));const rendered=s.common.filter(e=>e.type==='line'||e.type==='conditional'&&selected[e.key]===e.value);const ep=s.endings[ending].entries.filter(e=>e.type==='line');const chars=rendered.concat(ep).reduce((a,x)=>a+x.text.length,0)+[...choices.values()].reduce((a,c)=>a+c.options[index].text.length,0);assert.ok(chars>6000&&chars<8500,`unexpected playthrough length ${chars}`);console.log(`${ending}, daily choice ${index+1}: ${rendered.length+ep.length} lines, ${chars} characters`);
}
console.log('PASS: 9 route combinations, 3 endings, 7 choices, conditional callbacks, pink theme, CG assets and minigame entry points.');
