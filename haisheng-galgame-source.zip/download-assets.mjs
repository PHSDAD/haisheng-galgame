import fs from 'node:fs/promises';
const sources = {
 'background-source.html':'https://potat0master.itch.io/free-visual-novel-backgrounds-school-mini-pack-1',
 'judy-source.html':'https://movies.disney.com/zootopia',
 'dist/assets/judy-reference.png':'https://www.pngfind.com/pngs/m/176-1760820_judy-zootopia-png-transparent-png.png',
 'dist/assets/campus.jpg':'https://img.itch.zone/aW1hZ2UvMzQ1ODAyOS8yMDgyMDgxMC5wbmc%3D/original/Tbq0b1.png',
 'dist/assets/courtyard.jpg':'https://gakaisozai.up.seesaa.net/01247252N000000003/149173015035682988179_BG540b_1280.jpg',
 'dist/assets/classroom.jpg':'https://booth.pximg.net/a4fa5cef-ade3-4526-aea8-cf4128f93f41/i/3759119/cc5f7fed-a297-4eac-9e23-6c47c9a53d10_base_resized.jpg'
};
await Promise.all(Object.entries(sources).map(async([name,url])=>{
 for(let attempt=0;attempt<3;attempt++){
  try { const r=await fetch(url,{signal:AbortSignal.timeout(25000)}); if(!r.ok)throw Error(`HTTP ${r.status}`);const data=Buffer.from(await r.arrayBuffer());await fs.writeFile(name,data);console.log(`${name}: ${data.length} bytes`);return; }
  catch(e){if(attempt===2)console.log(`${name}: FAILED ${e.cause?.code||e.message}`);}
 }
}));
